export function AnimalArt({ animal }: { animal: Animal }) {
  return <img src={`/animals/${animal.type}.svg?v=5`} alt={`${animal.name} 캐릭터 ${animal.nick}`} width="300" height="300" />;
}